#' Create structure of group search solutions.
#' @keywords internal 
create.tree <- function(history, subgroup){
  
  #-------------------------------------------------------#
  # Internal functions for tree building
  #-------------------------------------------------------#
  rbind.NA.fill <- function (...) {
    dargs <- list(...)
    if (!all(vapply(dargs, is.vector, TRUE))) 
      stop("all inputs must be vectors")
    if (!all(vapply(dargs, function(x) !is.null(names(x)), TRUE))) 
      stop("all input vectors must be named.")
    all.names <- unique(names(unlist(dargs)))
    out <- do.call(rbind, lapply(dargs, `[`, all.names))
    colnames(out) <- all.names
    out
  }
  
  paste4 <- function(x, sep = ", ") {
    x <- gsub("^\\s+|\\s+$", "", x) 
    ret <- paste(x[!is.na(x) & !(x %in% "")], collapse = sep)
    is.na(ret) <- ret == ""
    return(ret)
  }
  
  #-------------------------------------------------------#
  # Subgrouping history
  #-------------------------------------------------------#
  hist_list <- lapply(history[[length(history)]], "[[", "add_syntax")
  
  hist_list <- lapply(seq_along(hist_list), function(i){
    names(hist_list[[i]]) <- paste0("V", 1:length(hist_list[[i]]))
    hist_list[[i]]
  })
  
  
  #-------------------------------------------------------#
  # Create variables to go beside tree plot
  #-------------------------------------------------------#
  grp_sol <- unlist(lapply(lapply(history[[length(history)]], "[[", "grp_sol"), function(x){
    if(any(is.na(x))){ "" } else{ paste0(x,collapse=", ") }
  }))
  
  subgrp_sol <- unlist(lapply(lapply(history[[length(history)]], "[[", "subgrp_sol"), function(x){
    if(any(is.na(x))){ "" } else{ paste0(x,collapse=", ") }
  }))
  
  pruned <- unlist(lapply(lapply(history[[length(history)]], "[[", "pruned"), function(x){
    if(any(is.na(x))){ "" } else{ paste0(x,collapse=", ") }
  }))
  
  #-------------------------------------------------------#
  # Formatting for the additional columns
  #-------------------------------------------------------#
  format_character_vars <- function(x){
    if (!is.na(x)) {
      res <- as.character(x) 
    } else {
      res <- "" 
    } 
    return(res)
  }

  #-------------------------------------------------------#
  # Create tree
  #-------------------------------------------------------#
  df <- as.data.frame(do.call(rbind.NA.fill, hist_list))
  V0 <- rep("NULL MODEL", nrow(df))
  df <- cbind(V0, df)
  df$pathString <- apply(df, 1, function(x) paste4(x, sep = "/"))
  
  df$pruned <- pruned
  df$grp_sol <- grp_sol
  df$subgrp_sol <- subgrp_sol
  
  dt <- data.tree::as.Node(df)
  
  #-------------------------------------------------------#
  # Format columns
  #-------------------------------------------------------#
  SetFormat(dt, "grp_sol", format_character_vars)
  SetFormat(dt, "subgrp_sol", format_character_vars)
  SetFormat(dt, "pruned", format_character_vars)
  
  return(dt1)
  
  ##########################################################
  
  #-------------------------------------------------------#
  # All history
  #-------------------------------------------------------#
  hist_list <- lapply(history, function(x){
    lapply(x, "[[", "add_syntax")
  })

  new_list <- list()
  for(i in 1:length(hist_list)){ # i <- 1; j<- 1
    for(j in 1:length(hist_list[[i]])){
      
     tmp_list <- hist_list[[i]][[j]]
        
     names(tmp_list) <- paste0("V", 1:length(tmp_list))

     new_list <- append(new_list, list(tmp_list))
   }
  }
  
  hist_list <- new_list
  
  #-------------------------------------------------------#
  # Create variables to go beside tree plot
  #-------------------------------------------------------#
  stage  <- unlist(lapply(history, function(x){
    lapply(x, "[[", "stage")
  }))
    
  grp_sol  <- unlist(lapply(history, function(x){
    lapply(x, "[[", "grp_sol")
  }))
  
  subgrp_sol  <- unlist(lapply(history, function(x){
    lapply(x, "[[", "subgrp_sol")
  }))
  
  pruned  <- unlist(lapply(history, function(x){
    lapply(x, function(y) {
      if(any(is.na(y$pruned))){
        ""
      } else {
         paste0(y$pruned,collapse=", ")
      }
    })
  }))
  
  
    
  #-------------------------------------------------------#
  # Formatting for the additional columns
  #-------------------------------------------------------#
  format_character_vars <- function(x){
    if (!is.na(x)) {
      res <- as.character(x) 
    } else {
      res <- "" 
    } 
    return(res)
  }

  #-------------------------------------------------------#
  # Create tree
  #-------------------------------------------------------#
  df <- as.data.frame(do.call(rbind.NA.fill, hist_list))
  V0 <- rep("NULL MODEL", nrow(df))
  df <- cbind(V0, df)
  df$pathString <- apply(df, 1, function(x) paste4(x, sep = "/"))
  
  #df$pruned <- pruned
  df$grp_sol <- grp_sol
  df$subgrp_sol <- subgrp_sol
  df$stage <- stage
  df$pruned <- pruned
  dt <- data.tree::as.Node(df)
  
  #-------------------------------------------------------#
  # Format columns
  #-------------------------------------------------------#
  SetFormat(dt, "stage", format_character_vars)
  SetFormat(dt, "grp_sol", format_character_vars)
  SetFormat(dt, "subgrp_sol", format_character_vars)
  SetFormat(dt, "pruned", format_character_vars)

  print(dt, "stage", "grp_sol", "subgrp_sol", "pruned")

}
  
  
  
  ##################################################################
  # hist_list <- lapply(history, function(x){
  #   lapply(x, "[[", "add_syntax")
  # })
  # 
  # new_list <- list()
  # for(i in 1:length(hist_list)){ # i <- 1; j<- 1
  #   for(j in 1:length(hist_list[[i]])){
  #    new_list <- append(new_list, list(hist_list[[i]][[j]]))
  #  }
  # }
  ##################################################################
  
  
  # # which levels of list correspond to the group search?
  # grp_stage <- unlist(lapply(history, function(x){
  #   if(is.null(x[[1]]$stage)){
  #     FALSE
  #   } else {
  #     ifelse(x[[1]]$stage == "group",TRUE,FALSE)
  #   }
  # }))
  # 
  # grp_list <- lapply(history[grp_stage][[1]], "[[", "add_syntax")
  # 
  # grp_list <- lapply(seq_along(grp_list), function(i){
  #   names(grp_list[[i]]) <- paste0("V", 1:length(grp_list[[i]]))
  #   grp_list[[i]]
  # })
  # 
  # 
  # df <- as.data.frame(do.call(rbind.NA.fill, grp_list))
  # 
  # V0 <- rep("NULL MODEL", nrow(df))
  # 
  # df <- cbind(V0, df)
  # 
  # # look in the last column of the dataframe for 
  # 
  # df$pathString <- apply(df, 1, function(x) paste4(x, sep = "/"))
  # 
  # group <- seq(1:nrow(df))
  # 
  # df <- cbind(df, group)
  # 
  # stage <- rep("group",nrow(df))
  # 
  # df <- cbind(df, stage)
  # 
  # 
  # pruned<- unlist(lapply(lapply(history[grp_stage][[1]], "[[", "pruned"), function(x){
  #   if(any(is.na(x))){
  #     ""
  #   } else{
  #     paste0(x,collapse=", ")
  #   }
  # }))
  # 
  # df <- cbind(df, pruned)
  # df$pruned <- as.character(df$pruned)
  # 
  # dt1 <- data.tree::as.Node(df)
  # 
  # formatSolution <- function(x) {
  #   if (!is.na(x)) res <- FormatFixedDecimal(x, digits = 0)
  #   else res <- ""
  #   return (res)
  # }
  # 
  # formatStage <- function(x) {
  #   if (!is.na(x)) res <- as.character(x)
  #   else res <- ""
  #   return (res)
  # }
  # 
  # SetFormat(dt1, "group", formatSolution)
  # SetFormat(dt1, "stage", formatStage)
  # 
  # print(dt1, "stage", "group", "pruned")
  # 
  # 
  # #-------------------------------------------------------#
  # # Subgrouping history
  # #-------------------------------------------------------#
  # 
  # if(subgroup){
  #   
  #   # # which levels of list correspond to the group search?
  #   # sub_stage <- unlist(lapply(history, function(x){
  #   #   if(is.null(x[[1]]$stage)){
  #   #     FALSE
  #   #   } else {
  #   #     ifelse(x[[1]]$stage == "subgroup",TRUE,FALSE)
  #   #   }
  #   # }))
  #   
  #   sub_list <- lapply(history[[length(history)]], "[[", "add_syntax")
  #   
  #   sub_list <- lapply(seq_along(sub_list), function(i){
  #     names(sub_list[[i]]) <- paste0("V", 1:length(sub_list[[i]]))
  #     sub_list[[i]]
  #   })
  #   
  #   ds <- as.data.frame(do.call(rbind.NA.fill, sub_list))
  # 
  #   V0 <- rep("NULL MODEL", nrow(ds))
  # 
  #   ds <- cbind(V0, ds)
  # 
  #   ds$pathString <- apply(ds, 1, function(x) paste4(x, sep = "/"))
  #   
  #   
  #   #------------------------------------------------------------#
  #   # create columns for tree plot
  #   #------------------------------------------------------------#
  #   
  #   group <- seq(1:nrow(ds))
  #   
  #   df <- cbind(df, group)
  #   
  #   stage <- rep("group",nrow(df))
  #   
  #   df <- cbind(df, stage)
  #   
  #   
  #   pruned<- unlist(lapply(lapply(history[[length(history)]], "[[", "pruned"), function(x){
  #     if(any(is.na(x))){
  #       ""
  #     } else{
  #       paste0(x,collapse=", ")
  #     }
  #   }))
  #   
  #   
  # }
  # 
  # 
  # 
  # 
  # 
  # 
  # df <- cbind(df, pruned)
  # df$pruned <- as.character(df$pruned)
  # 
  # dt1 <- data.tree::as.Node(df)
  # 
  # formatSolution <- function(x) {
  #   if (!is.na(x)) res <- FormatFixedDecimal(x, digits = 0)
  #   else res <- ""
  #   return (res)
  # }
  # 
  # formatStage <- function(x) {
  #   if (!is.na(x)) res <- as.character(x)
  #   else res <- ""
  #   return (res)
  # }
  # 
  # SetFormat(dt1, "group", formatSolution)
  # SetFormat(dt1, "stage", formatStage)
  # 
  # print(dt1, "stage", "group", "pruned")
  # 
  # 
  # 
  # 
  # if (subgroup){
  #   subgrp_stage <- lapply(history, function(x){x[[1]]$stage == "group"})
  # }
  # 
  # 
  # hist_list <- lapply(history[[length(history)]], "[[", "add_syntax")
  # 
  # 
  # 
  # pruned  <- lapply(history[[length(history)]], "[[", "pruned")
  # stage   <- lapply(history[[length(history)]], "[[", "stage")

  
  
  
  # as.data.frame(
  #   dt1, 
  #   row.names = NULL, 
  #   optional = FALSE,
  #   traversal = c(
  #     #"pre-order",
  #     "post-order" 
  #     #"in-order", 
  #     #"level",
  #     #"ancestor"
  #   ), 
  #   pruneFun = NULL, 
  #   filterFun = NULL, 
  #   format = FALSE,
  #   inheritFromAncestors = FALSE
  # )
  # 
  # #get the nodes corresponding to the struct elements as a traversal
  # trav <-  Traverse(dt1, filterFun = isNotRoot)
  # 
  # #order alphabetically
  # trav <- trav[order(Get(trav, "name"))]

  #print(dt1, "solution", limit = 20)


