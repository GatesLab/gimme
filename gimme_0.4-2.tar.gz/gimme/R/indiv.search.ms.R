#' Individual-level search. Used in gimmeSEM, aggSEM, indSEM.
#' @param dat A list containing information created in setup().
#' @param grp A list containing group-level information. NULL in aggSEM and
#' indSEM.
#' @param ind A list containing individual- and (potentially) subgroup-level
#' information.
#' @return Lists associated with coefficients, fit indices, etc.
#' @keywords internal 
indiv.search.ms <- function(dat, grp, ind, ms_tol, ms_allow){
  
  ##########################
  # j   <- 1
  # dat <- dat
  # grp <- grp[[j]]
  # grp$n_group_paths <- 0
  # grp$group_paths   <- character()
  # ind <- sub_all[[j]]$ind
  # ms_tol <- ms_tol
  # ms_allow  <- ms_allow
  grp <- old_grp[[1]]
  ind <- old_ind[[1]]
  ########################
  

  #-----------------------------------------------#
  # Prepare data depending on proc (agg vs gimme) #
  #-----------------------------------------------#
  if (dat$agg){
    
    ind   <- NULL
    n_ind <- 1
    data_all <- do.call(rbind, dat$ts_list)
    colnames(data_all) <- dat$varnames
    
  } else {
    
    ind$ind_paths   <-  vector("list", dat$n_subj)
    ind$n_ind_paths <- 0
    n_ind           <- dat$n_subj
    
  }
  
  
  
  all_ind <- replicate(n_ind, list(), simplify = FALSE)
  
  #-----------------------------------------------#
  # Prepare output                                #
  #-----------------------------------------------#
  status  <- list()
  fits    <- list()
  coefs   <- list()
  betas   <- list()
  vcov    <- list()
  plots   <- list()
  
  for (k in 1:n_ind){
    
    if (dat$agg){
      
      data_list <- data_all
      
    } else {
      
      data_list <- dat$ts_list[[k]]
      
      writeLines(paste0("individual-level search, subject ", k, " (", names(dat$ts_list)[k],")"))
      
    }
    
    #-----------------------------------------------#
    # Conduct the ind level search                  #
    #-----------------------------------------------#
    s1.ind <- search.paths(
      base_syntax  = dat$syntax, 
      fixed_syntax = c(grp$group_paths, ind$sub_paths[[k]]),
      add_syntax   = character(),
      n_paths      = 0,
      data_list    = data_list,
      elig_paths   = dat$candidate_paths,
      prop_cutoff  = NULL,
      n_subj       = 1,
      chisq_cutoff = qchisq(.99, 1),
      subgroup_stage = FALSE,
      ms_allow       = TRUE,
      ms_tol         = ms_tol
    )
  

    
    #-----------------------------------------------#
    # Conduct the first pruning                     #
    #-----------------------------------------------#
    p1.ind <- lapply(seq_along(s1.ind), function(i){
      
      if(ms_allow){
        writeLines(paste0("pruning solution ", i ," for subject ", k, "..."))
      }
      
      prune.paths(
        base_syntax    = dat$syntax,
        fixed_syntax   = c(grp$group_paths, ind$sub_paths[[k]]),
        add_syntax     = s1.ind[[length(s1.ind)]][[i]]$add_syntax,
        data_list      = data_list,
        n_paths        = s1.ind[[length(s1.ind)]][[i]]$n_paths,
        n_subj         = 1,
        prop_cutoff    = NULL,
        elig_paths     = s1.ind[[length(s1.ind)]][[i]]$add_syntax,
        subgroup_stage = FALSE
      )
      
    })
    
    #-----------------------------------------------#
    # Add the pruning step to the indiv. history    #
    #-----------------------------------------------#
    
    s1.ind[[length(s1.ind)]] <- lapply(seq_along(s1.ind[[length(s1.ind)]]), function(i){
      
      s1.ind[[length(s1.ind)]][[i]]$stage <- "individual"
      
      pruned <- setdiff(
        s1.ind[[length(s1.ind)]][[i]]$add_syntax, 
        p1.ind[[1]]$add_syntax
      )
      
      if(length(pruned) != 0){
        s1.ind[[length(s1.ind)]][[i]]$pruned <- pruned
      } else {
        s1.ind[[length(s1.ind)]][[i]]$pruned <- NA
      }
      s1.ind[[length(s1.ind)]][[i]]
      
    })
    
    
    #-----------------------------------------------#
    # One final search phase                        #
    #-----------------------------------------------# 
    
    s2.ind <- lapply(seq_along(p1.ind), function(i){
      
      if(ms_allow){
        writeLines(paste0("searching solution ", i ," for subject ", k, "..."))
      }
      
      search.paths(
        base_syntax  = dat$syntax, 
        fixed_syntax = c(grp$group_paths, ind$sub_paths[[k]]),
        add_syntax   = p1.ind[[i]]$add_syntax,
        n_paths      = p1.ind[[i]]$n_paths,
        data_list    = data_list,
        elig_paths   = dat$candidate_paths,
        prop_cutoff  = NULL,
        n_subj       = 1,
        chisq_cutoff = 0,
        subgroup_stage = FALSE,
        ms_allow       = TRUE,
        ms_tol         = ms_tol
      )
      
    })
  
    ind_history <- append(s1.ind, s2.ind)
    
    all_ind[[k]] <- ind_history
    
  }

    #-----------------------------------------------#
    # Wrap up                                       #
    #-----------------------------------------------# 
    # walk through all subjects
    # old_res <- lapply(seq_along(all_ind_history), function(i){
    #   hist_subj_i <- all_ind_history[[i]]
    #   # now walk through all solutions for subject i
    #   hist_subj_i[[length(hist_subj_i)]] <- lapply(seq_along(hist_subj_i[[length(hist_subj_i)]]), function(j){
    #     
    #     
    #     hist_subj_i[[length(hist_subj_i)]][[j]]$ind <- ind
    #     hist_subj_i[[length(hist_subj_i)]][[j]]$ind$ind_paths[[i]] <- hist_subj_i[[length(hist_subj_i)]][[j]]$add_syntax
    #     hist_subj_i[[length(hist_subj_i)]][[j]]$ind$n_ind_paths[i] <- hist_subj_i[[length(hist_subj_i)]][[j]]$n_paths
    #     
    #     # hist_subj_i[[length(hist_subj_i)]][[j]]$s10 <- get.params(
    #     #   dat, 
    #     #   grp, 
    #     #   hist_subj_i[[length(hist_subj_i)]][[j]]$ind, 
    #     #   i
    #     # )
    #     
    #     hist_subj_i[[length(hist_subj_i)]][[j]]
    #   })
    #   
    #   hist_subj_i
    #       
    # })
    
    
    
  # status[[k]] <- s10$status
  # fits[[k]]   <- s10$ind_fit
  # coefs[[k]]  <- s10$ind_coefs
  # betas[[k]]  <- s10$ind_betas
  # vcov[[k]]   <- s10$ind_vcov
  # plots[[k]]  <- s10$ind_plot

  # if (dat$agg){
  #   names(status) <- names(fits) <- names(coefs) <- 
  #     names(betas) <- names(vcov) <- names(plots) <- "all"
  #   # } else if (ind$n_ind_paths[k] > 0 & !dat$agg){
  #   #   names(status) <- names(fits) <- names(coefs) <- 
  #   #     names(betas) <- names(vcov) <- names(plots) <- names(dat$ts_list)
  # } else {
  #   names(status) <- names(fits) <- names(coefs) <- 
  #     names(betas) <- names(vcov) <- names(plots) <- names(dat$ts_list)
  # }
  # 
  # res <- list("status" = status,
  #             "fits"   = fits,
  #             "coefs"  = coefs,
  #             "betas"  = betas,
  #             "vcov"   = vcov,
  #             "plots"  = plots,
  #             "ind"    = ind)
  #
  # return(res)
  return(all_ind_history)
}